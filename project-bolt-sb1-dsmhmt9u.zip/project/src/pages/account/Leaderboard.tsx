import React from 'react';

export default function Leaderboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Leaderboard</h1>
      {/* Add your Leaderboard content here */}
    </div>
  );
}