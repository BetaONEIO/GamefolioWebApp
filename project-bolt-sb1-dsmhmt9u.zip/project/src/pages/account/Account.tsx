import React from 'react';

export default function Account() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Account Settings</h1>
      {/* Add your Account content here */}
    </div>
  );
}