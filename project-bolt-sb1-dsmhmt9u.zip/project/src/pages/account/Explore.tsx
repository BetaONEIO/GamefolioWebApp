import React from 'react';

export default function Explore() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Explore</h1>
      {/* Add your Explore content here */}
    </div>
  );
}