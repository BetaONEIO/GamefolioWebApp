import React from 'react';

export default function Settings() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      {/* Add your Settings content here */}
    </div>
  );
}